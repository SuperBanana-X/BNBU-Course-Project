-- Diagnostic 1: Meal Demand Diagnosis
-- Business question: Which meals and categories contribute most to total order demand?

-- output: 04_meal_category_demand_diagnosis.csv
SELECT
    category,
    cuisine,
    COUNT(DISTINCT meal_id) AS meals,
    SUM(num_orders) AS total_orders,
    ROUND(AVG(num_orders), 2) AS avg_orders_per_observation,
    ROUND(SUM(num_orders) * 100.0 / SUM(SUM(num_orders)) OVER (), 2) AS order_share_pct,
    RANK() OVER (ORDER BY SUM(num_orders) DESC) AS demand_rank
FROM v_train_enriched
GROUP BY category, cuisine
ORDER BY total_orders DESC;

-- output: 05_top_meal_demand_diagnosis.csv
SELECT
    meal_id,
    category,
    cuisine,
    SUM(num_orders) AS total_orders,
    ROUND(AVG(num_orders), 2) AS avg_orders_per_observation,
    COUNT(DISTINCT center_id) AS active_centers,
    COUNT(DISTINCT week) AS active_weeks,
    ROUND(SUM(num_orders) * 100.0 / SUM(SUM(num_orders)) OVER (), 2) AS order_share_pct,
    RANK() OVER (ORDER BY SUM(num_orders) DESC) AS meal_demand_rank
FROM v_train_enriched
GROUP BY meal_id, category, cuisine
ORDER BY total_orders DESC
LIMIT 30;

-- Diagnostic 2: Center Demand Volatility Diagnosis
-- Business question: Which fulfilment centers show the highest demand volatility?

-- output: 06_center_demand_volatility_diagnosis.csv
WITH center_week AS (
    SELECT
        center_id,
        city_code,
        region_code,
        center_type,
        op_area,
        week,
        SUM(num_orders) AS weekly_orders
    FROM v_train_enriched
    GROUP BY center_id, city_code, region_code, center_type, op_area, week
),
center_stats AS (
    SELECT
        center_id,
        city_code,
        region_code,
        center_type,
        op_area,
        COUNT(*) AS observed_weeks,
        SUM(weekly_orders) AS total_orders,
        AVG(weekly_orders) AS avg_weekly_orders,
        sqrt(AVG(weekly_orders * weekly_orders) - AVG(weekly_orders) * AVG(weekly_orders)) AS stddev_weekly_orders
    FROM center_week
    GROUP BY center_id, city_code, region_code, center_type, op_area
)
SELECT
    center_id,
    city_code,
    region_code,
    center_type,
    op_area,
    observed_weeks,
    total_orders,
    ROUND(avg_weekly_orders, 2) AS avg_weekly_orders,
    ROUND(stddev_weekly_orders, 2) AS stddev_weekly_orders,
    ROUND(stddev_weekly_orders / NULLIF(avg_weekly_orders, 0), 4) AS coefficient_of_variation,
    ROUND(avg_weekly_orders / NULLIF(op_area, 0), 2) AS orders_per_op_area,
    RANK() OVER (ORDER BY stddev_weekly_orders / NULLIF(avg_weekly_orders, 0) DESC) AS volatility_rank
FROM center_stats
ORDER BY coefficient_of_variation DESC;

-- output: 07_top_volatile_centers.csv
WITH center_week AS (
    SELECT
        center_id,
        city_code,
        region_code,
        center_type,
        op_area,
        week,
        SUM(num_orders) AS weekly_orders
    FROM v_train_enriched
    GROUP BY center_id, city_code, region_code, center_type, op_area, week
),
center_stats AS (
    SELECT
        center_id,
        city_code,
        region_code,
        center_type,
        op_area,
        COUNT(*) AS observed_weeks,
        SUM(weekly_orders) AS total_orders,
        AVG(weekly_orders) AS avg_weekly_orders,
        sqrt(AVG(weekly_orders * weekly_orders) - AVG(weekly_orders) * AVG(weekly_orders)) AS stddev_weekly_orders
    FROM center_week
    GROUP BY center_id, city_code, region_code, center_type, op_area
)
SELECT
    center_id,
    city_code,
    region_code,
    center_type,
    op_area,
    total_orders,
    ROUND(avg_weekly_orders, 2) AS avg_weekly_orders,
    ROUND(stddev_weekly_orders, 2) AS stddev_weekly_orders,
    ROUND(stddev_weekly_orders / NULLIF(avg_weekly_orders, 0), 4) AS coefficient_of_variation,
    ROUND(avg_weekly_orders / NULLIF(op_area, 0), 2) AS orders_per_op_area
FROM center_stats
ORDER BY coefficient_of_variation DESC
LIMIT 20;

-- Diagnostic 3: Promotion and Discount Diagnosis
-- Business question: Are promotion emails, homepage featuring, and discounts associated with higher orders?

-- output: 08_promotion_effect_diagnosis.csv
SELECT
    emailer_for_promotion,
    homepage_featured,
    CASE
        WHEN emailer_for_promotion = 1 AND homepage_featured = 1 THEN 'Email + Homepage'
        WHEN emailer_for_promotion = 1 THEN 'Email Only'
        WHEN homepage_featured = 1 THEN 'Homepage Only'
        ELSE 'No Promotion'
    END AS promotion_group,
    COUNT(*) AS observations,
    SUM(num_orders) AS total_orders,
    ROUND(AVG(num_orders), 2) AS avg_orders,
    ROUND(AVG(discount_rate), 4) AS avg_discount_rate
FROM v_train_enriched
GROUP BY emailer_for_promotion, homepage_featured
ORDER BY avg_orders DESC;

-- output: 09_discount_effect_diagnosis.csv
SELECT
    discount_bucket,
    COUNT(*) AS observations,
    SUM(num_orders) AS total_orders,
    ROUND(AVG(num_orders), 2) AS avg_orders,
    ROUND(AVG(discount_rate), 4) AS avg_discount_rate
FROM v_train_enriched
GROUP BY discount_bucket
ORDER BY avg_discount_rate;

-- output: 10_promotion_discount_interaction.csv
SELECT
    CASE
        WHEN promotion_flag = 1 THEN 'Promoted'
        ELSE 'Not Promoted'
    END AS promotion_status,
    discount_bucket,
    COUNT(*) AS observations,
    SUM(num_orders) AS total_orders,
    ROUND(AVG(num_orders), 2) AS avg_orders
FROM v_train_enriched
GROUP BY promotion_status, discount_bucket
ORDER BY promotion_status DESC, avg_orders DESC;
