PRAGMA foreign_keys = ON;

DROP VIEW IF EXISTS v_train_enriched;
DROP VIEW IF EXISTS v_test_enriched;
DROP TABLE IF EXISTS train;
DROP TABLE IF EXISTS test;
DROP TABLE IF EXISTS meal_info;
DROP TABLE IF EXISTS fulfilment_center_info;

CREATE TABLE meal_info (
    meal_id INTEGER PRIMARY KEY,
    category TEXT NOT NULL,
    cuisine TEXT NOT NULL
);

CREATE TABLE fulfilment_center_info (
    center_id INTEGER PRIMARY KEY,
    city_code INTEGER NOT NULL,
    region_code INTEGER NOT NULL,
    center_type TEXT NOT NULL,
    op_area REAL NOT NULL
);

CREATE TABLE train (
    id INTEGER PRIMARY KEY,
    week INTEGER NOT NULL,
    center_id INTEGER NOT NULL,
    meal_id INTEGER NOT NULL,
    checkout_price REAL NOT NULL,
    base_price REAL NOT NULL,
    emailer_for_promotion INTEGER NOT NULL,
    homepage_featured INTEGER NOT NULL,
    num_orders INTEGER NOT NULL,
    FOREIGN KEY (center_id) REFERENCES fulfilment_center_info(center_id),
    FOREIGN KEY (meal_id) REFERENCES meal_info(meal_id)
);

CREATE TABLE test (
    id INTEGER PRIMARY KEY,
    week INTEGER NOT NULL,
    center_id INTEGER NOT NULL,
    meal_id INTEGER NOT NULL,
    checkout_price REAL NOT NULL,
    base_price REAL NOT NULL,
    emailer_for_promotion INTEGER NOT NULL,
    homepage_featured INTEGER NOT NULL,
    FOREIGN KEY (center_id) REFERENCES fulfilment_center_info(center_id),
    FOREIGN KEY (meal_id) REFERENCES meal_info(meal_id)
);

CREATE INDEX idx_train_week ON train(week);
CREATE INDEX idx_train_center_meal_week ON train(center_id, meal_id, week);
CREATE INDEX idx_train_center_week ON train(center_id, week);
CREATE INDEX idx_train_meal_week ON train(meal_id, week);
CREATE INDEX idx_test_center_meal_week ON test(center_id, meal_id, week);

CREATE VIEW v_train_enriched AS
SELECT
    t.id,
    t.week,
    t.center_id,
    c.city_code,
    c.region_code,
    c.center_type,
    c.op_area,
    t.meal_id,
    m.category,
    m.cuisine,
    t.checkout_price,
    t.base_price,
    ROUND((t.base_price - t.checkout_price) / NULLIF(t.base_price, 0), 4) AS discount_rate,
    CASE
        WHEN (t.base_price - t.checkout_price) / NULLIF(t.base_price, 0) < 0 THEN 'price_above_base'
        WHEN (t.base_price - t.checkout_price) / NULLIF(t.base_price, 0) = 0 THEN 'no_discount'
        WHEN (t.base_price - t.checkout_price) / NULLIF(t.base_price, 0) <= 0.05 THEN '0-5%'
        WHEN (t.base_price - t.checkout_price) / NULLIF(t.base_price, 0) <= 0.10 THEN '5-10%'
        WHEN (t.base_price - t.checkout_price) / NULLIF(t.base_price, 0) <= 0.20 THEN '10-20%'
        ELSE '>20%'
    END AS discount_bucket,
    t.emailer_for_promotion,
    t.homepage_featured,
    CASE
        WHEN t.emailer_for_promotion = 1 OR t.homepage_featured = 1 THEN 1
        ELSE 0
    END AS promotion_flag,
    t.num_orders,
    ROUND(t.checkout_price * t.num_orders, 2) AS gross_sales_proxy
FROM train AS t
JOIN meal_info AS m
    ON t.meal_id = m.meal_id
JOIN fulfilment_center_info AS c
    ON t.center_id = c.center_id;

CREATE VIEW v_test_enriched AS
SELECT
    t.id,
    t.week,
    t.center_id,
    c.city_code,
    c.region_code,
    c.center_type,
    c.op_area,
    t.meal_id,
    m.category,
    m.cuisine,
    t.checkout_price,
    t.base_price,
    ROUND((t.base_price - t.checkout_price) / NULLIF(t.base_price, 0), 4) AS discount_rate,
    t.emailer_for_promotion,
    t.homepage_featured,
    CASE
        WHEN t.emailer_for_promotion = 1 OR t.homepage_featured = 1 THEN 1
        ELSE 0
    END AS promotion_flag
FROM test AS t
JOIN meal_info AS m
    ON t.meal_id = m.meal_id
JOIN fulfilment_center_info AS c
    ON t.center_id = c.center_id;
