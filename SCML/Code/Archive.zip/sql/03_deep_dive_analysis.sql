-- Deep Dive 1: Demand Risk Classification for Inventory Planning
-- Business question: Which center-meal combinations are high demand stable,
-- high demand volatile, low demand promotion dependent, or low priority?
-- Business interpretation:
-- high demand stable combinations need stable supply protection;
-- high demand volatile combinations need flexible replenishment, not blind overstocking.

-- output: 11_demand_risk_classification.csv
WITH center_meal_week AS (
    SELECT
        center_id,
        meal_id,
        category,
        cuisine,
        city_code,
        region_code,
        center_type,
        op_area,
        week,
        SUM(num_orders) AS weekly_orders,
        MAX(promotion_flag) AS promoted_in_week
    FROM v_train_enriched
    GROUP BY center_id, meal_id, category, cuisine, city_code, region_code, center_type, op_area, week
),
metrics AS (
    SELECT
        center_id,
        meal_id,
        category,
        cuisine,
        city_code,
        region_code,
        center_type,
        op_area,
        COUNT(*) AS observed_weeks,
        SUM(weekly_orders) AS total_orders,
        AVG(weekly_orders) AS avg_weekly_orders,
        sqrt(AVG(weekly_orders * weekly_orders) - AVG(weekly_orders) * AVG(weekly_orders)) AS stddev_weekly_orders,
        SUM(CASE WHEN promoted_in_week = 1 THEN weekly_orders ELSE 0 END) * 1.0 / NULLIF(SUM(weekly_orders), 0) AS promo_order_share,
        AVG(CASE WHEN promoted_in_week = 1 THEN weekly_orders END) AS avg_orders_promoted_weeks,
        AVG(CASE WHEN promoted_in_week = 0 THEN weekly_orders END) AS avg_orders_non_promoted_weeks
    FROM center_meal_week
    GROUP BY center_id, meal_id, category, cuisine, city_code, region_code, center_type, op_area
),
scored AS (
    SELECT
        *,
        stddev_weekly_orders / NULLIF(avg_weekly_orders, 0) AS coefficient_of_variation,
        (avg_orders_promoted_weeks - avg_orders_non_promoted_weeks)
            / NULLIF(avg_orders_non_promoted_weeks, 0) AS promo_lift_ratio,
        PERCENT_RANK() OVER (ORDER BY avg_weekly_orders) AS demand_percentile,
        PERCENT_RANK() OVER (ORDER BY stddev_weekly_orders / NULLIF(avg_weekly_orders, 0)) AS volatility_percentile
    FROM metrics
)
SELECT
    center_id,
    meal_id,
    category,
    cuisine,
    city_code,
    region_code,
    center_type,
    op_area,
    observed_weeks,
    total_orders,
    ROUND(avg_weekly_orders, 2) AS avg_weekly_orders,
    ROUND(stddev_weekly_orders, 2) AS stddev_weekly_orders,
    ROUND(coefficient_of_variation, 4) AS coefficient_of_variation,
    ROUND(promo_order_share, 4) AS promo_order_share,
    ROUND(promo_lift_ratio, 4) AS promo_lift_ratio,
    ROUND(demand_percentile, 4) AS demand_percentile,
    ROUND(volatility_percentile, 4) AS volatility_percentile,
    CASE
        WHEN demand_percentile >= 0.70 AND volatility_percentile < 0.65 THEN 'High Demand Stable'
        WHEN demand_percentile >= 0.70 AND volatility_percentile >= 0.65 THEN 'High Demand Volatile'
        WHEN demand_percentile < 0.70
            AND (COALESCE(promo_lift_ratio, 0) >= 0.75 OR COALESCE(promo_order_share, 0) >= 0.35)
            THEN 'Low Demand Promotion Dependent'
        ELSE 'Low Demand Low Priority'
    END AS demand_risk_class
FROM scored
ORDER BY demand_percentile DESC, volatility_percentile DESC;

-- output: 12_demand_risk_class_summary.csv
WITH center_meal_week AS (
    SELECT
        center_id,
        meal_id,
        category,
        cuisine,
        city_code,
        region_code,
        center_type,
        op_area,
        week,
        SUM(num_orders) AS weekly_orders,
        MAX(promotion_flag) AS promoted_in_week
    FROM v_train_enriched
    GROUP BY center_id, meal_id, category, cuisine, city_code, region_code, center_type, op_area, week
),
metrics AS (
    SELECT
        center_id,
        meal_id,
        category,
        cuisine,
        city_code,
        region_code,
        center_type,
        op_area,
        COUNT(*) AS observed_weeks,
        SUM(weekly_orders) AS total_orders,
        AVG(weekly_orders) AS avg_weekly_orders,
        sqrt(AVG(weekly_orders * weekly_orders) - AVG(weekly_orders) * AVG(weekly_orders)) AS stddev_weekly_orders,
        SUM(CASE WHEN promoted_in_week = 1 THEN weekly_orders ELSE 0 END) * 1.0 / NULLIF(SUM(weekly_orders), 0) AS promo_order_share,
        AVG(CASE WHEN promoted_in_week = 1 THEN weekly_orders END) AS avg_orders_promoted_weeks,
        AVG(CASE WHEN promoted_in_week = 0 THEN weekly_orders END) AS avg_orders_non_promoted_weeks
    FROM center_meal_week
    GROUP BY center_id, meal_id, category, cuisine, city_code, region_code, center_type, op_area
),
scored AS (
    SELECT
        *,
        stddev_weekly_orders / NULLIF(avg_weekly_orders, 0) AS coefficient_of_variation,
        (avg_orders_promoted_weeks - avg_orders_non_promoted_weeks)
            / NULLIF(avg_orders_non_promoted_weeks, 0) AS promo_lift_ratio,
        PERCENT_RANK() OVER (ORDER BY avg_weekly_orders) AS demand_percentile,
        PERCENT_RANK() OVER (ORDER BY stddev_weekly_orders / NULLIF(avg_weekly_orders, 0)) AS volatility_percentile
    FROM metrics
),
classified AS (
    SELECT
        *,
        CASE
            WHEN demand_percentile >= 0.70 AND volatility_percentile < 0.65 THEN 'High Demand Stable'
            WHEN demand_percentile >= 0.70 AND volatility_percentile >= 0.65 THEN 'High Demand Volatile'
            WHEN demand_percentile < 0.70
                AND (COALESCE(promo_lift_ratio, 0) >= 0.75 OR COALESCE(promo_order_share, 0) >= 0.35)
                THEN 'Low Demand Promotion Dependent'
            ELSE 'Low Demand Low Priority'
        END AS demand_risk_class
    FROM scored
)
SELECT
    demand_risk_class,
    COUNT(*) AS center_meal_combinations,
    SUM(total_orders) AS total_orders,
    ROUND(AVG(avg_weekly_orders), 2) AS avg_weekly_orders,
    ROUND(AVG(coefficient_of_variation), 4) AS avg_coefficient_of_variation,
    ROUND(AVG(COALESCE(promo_lift_ratio, 0)), 4) AS avg_promo_lift_ratio
FROM classified
GROUP BY demand_risk_class
ORDER BY total_orders DESC;

-- Deep Dive 2: Replenishment Priority and Flexible Supply Planning
-- Business question: Which center-meal combinations should receive replenishment priority,
-- and which combinations require more flexible replenishment planning?
-- The priority score represents management attention, not a direct instruction to overstock.

-- output: 13_replenishment_priority_score.csv
WITH center_meal_week AS (
    SELECT
        center_id,
        meal_id,
        category,
        cuisine,
        city_code,
        region_code,
        center_type,
        op_area,
        week,
        SUM(num_orders) AS weekly_orders,
        MAX(promotion_flag) AS promoted_in_week
    FROM v_train_enriched
    GROUP BY center_id, meal_id, category, cuisine, city_code, region_code, center_type, op_area, week
),
metrics AS (
    SELECT
        center_id,
        meal_id,
        category,
        cuisine,
        city_code,
        region_code,
        center_type,
        op_area,
        COUNT(*) AS observed_weeks,
        SUM(weekly_orders) AS total_orders,
        AVG(weekly_orders) AS avg_weekly_orders,
        sqrt(AVG(weekly_orders * weekly_orders) - AVG(weekly_orders) * AVG(weekly_orders)) AS stddev_weekly_orders,
        SUM(CASE WHEN promoted_in_week = 1 THEN weekly_orders ELSE 0 END) * 1.0 / NULLIF(SUM(weekly_orders), 0) AS promo_order_share,
        AVG(CASE WHEN promoted_in_week = 1 THEN weekly_orders END) AS avg_orders_promoted_weeks,
        AVG(CASE WHEN promoted_in_week = 0 THEN weekly_orders END) AS avg_orders_non_promoted_weeks,
        AVG(weekly_orders) / NULLIF(op_area, 0) AS orders_per_op_area
    FROM center_meal_week
    GROUP BY center_id, meal_id, category, cuisine, city_code, region_code, center_type, op_area
),
ranked AS (
    SELECT
        *,
        stddev_weekly_orders / NULLIF(avg_weekly_orders, 0) AS coefficient_of_variation,
        (avg_orders_promoted_weeks - avg_orders_non_promoted_weeks)
            / NULLIF(avg_orders_non_promoted_weeks, 0) AS promo_lift_ratio,
        PERCENT_RANK() OVER (ORDER BY avg_weekly_orders) AS demand_percentile,
        PERCENT_RANK() OVER (ORDER BY stddev_weekly_orders / NULLIF(avg_weekly_orders, 0)) AS volatility_percentile,
        PERCENT_RANK() OVER (ORDER BY COALESCE((avg_orders_promoted_weeks - avg_orders_non_promoted_weeks)
            / NULLIF(avg_orders_non_promoted_weeks, 0), 0)) AS promo_response_percentile,
        PERCENT_RANK() OVER (ORDER BY orders_per_op_area) AS op_area_efficiency_percentile
    FROM metrics
),
scored AS (
    SELECT
        *,
        CASE
            WHEN demand_percentile >= 0.90 THEN 5
            WHEN demand_percentile >= 0.75 THEN 4
            WHEN demand_percentile >= 0.50 THEN 3
            WHEN demand_percentile >= 0.25 THEN 2
            ELSE 1
        END AS demand_scale_score,
        CASE
            WHEN volatility_percentile >= 0.90 THEN 5
            WHEN volatility_percentile >= 0.75 THEN 4
            WHEN volatility_percentile >= 0.50 THEN 3
            WHEN volatility_percentile >= 0.25 THEN 2
            ELSE 1
        END AS demand_volatility_score,
        CASE
            WHEN promo_response_percentile >= 0.90 THEN 5
            WHEN promo_response_percentile >= 0.75 THEN 4
            WHEN promo_response_percentile >= 0.50 THEN 3
            WHEN promo_response_percentile >= 0.25 THEN 2
            ELSE 1
        END AS promotion_response_score,
        CASE
            WHEN op_area_efficiency_percentile >= 0.90 THEN 5
            WHEN op_area_efficiency_percentile >= 0.75 THEN 4
            WHEN op_area_efficiency_percentile >= 0.50 THEN 3
            WHEN op_area_efficiency_percentile >= 0.25 THEN 2
            ELSE 1
        END AS orders_per_op_area_score
    FROM ranked
)
SELECT
    center_id,
    meal_id,
    category,
    cuisine,
    city_code,
    region_code,
    center_type,
    op_area,
    observed_weeks,
    total_orders,
    ROUND(avg_weekly_orders, 2) AS avg_weekly_orders,
    ROUND(coefficient_of_variation, 4) AS coefficient_of_variation,
    ROUND(COALESCE(promo_lift_ratio, 0), 4) AS promo_lift_ratio,
    ROUND(orders_per_op_area, 2) AS orders_per_op_area,
    demand_scale_score,
    demand_volatility_score,
    promotion_response_score,
    orders_per_op_area_score,
    demand_scale_score + demand_volatility_score + promotion_response_score + orders_per_op_area_score AS replenishment_priority_score
FROM scored
ORDER BY replenishment_priority_score DESC, total_orders DESC;

-- output: 14_top_replenishment_priority.csv
SELECT *
FROM (
    WITH center_meal_week AS (
        SELECT
            center_id,
            meal_id,
            category,
            cuisine,
            city_code,
            region_code,
            center_type,
            op_area,
            week,
            SUM(num_orders) AS weekly_orders,
            MAX(promotion_flag) AS promoted_in_week
        FROM v_train_enriched
        GROUP BY center_id, meal_id, category, cuisine, city_code, region_code, center_type, op_area, week
    ),
    metrics AS (
        SELECT
            center_id,
            meal_id,
            category,
            cuisine,
            city_code,
            region_code,
            center_type,
            op_area,
            COUNT(*) AS observed_weeks,
            SUM(weekly_orders) AS total_orders,
            AVG(weekly_orders) AS avg_weekly_orders,
            sqrt(AVG(weekly_orders * weekly_orders) - AVG(weekly_orders) * AVG(weekly_orders)) AS stddev_weekly_orders,
            SUM(CASE WHEN promoted_in_week = 1 THEN weekly_orders ELSE 0 END) * 1.0 / NULLIF(SUM(weekly_orders), 0) AS promo_order_share,
            AVG(CASE WHEN promoted_in_week = 1 THEN weekly_orders END) AS avg_orders_promoted_weeks,
            AVG(CASE WHEN promoted_in_week = 0 THEN weekly_orders END) AS avg_orders_non_promoted_weeks,
            AVG(weekly_orders) / NULLIF(op_area, 0) AS orders_per_op_area
        FROM center_meal_week
        GROUP BY center_id, meal_id, category, cuisine, city_code, region_code, center_type, op_area
    ),
    ranked AS (
        SELECT
            *,
            stddev_weekly_orders / NULLIF(avg_weekly_orders, 0) AS coefficient_of_variation,
            (avg_orders_promoted_weeks - avg_orders_non_promoted_weeks)
                / NULLIF(avg_orders_non_promoted_weeks, 0) AS promo_lift_ratio,
            PERCENT_RANK() OVER (ORDER BY avg_weekly_orders) AS demand_percentile,
            PERCENT_RANK() OVER (ORDER BY stddev_weekly_orders / NULLIF(avg_weekly_orders, 0)) AS volatility_percentile,
            PERCENT_RANK() OVER (ORDER BY COALESCE((avg_orders_promoted_weeks - avg_orders_non_promoted_weeks)
                / NULLIF(avg_orders_non_promoted_weeks, 0), 0)) AS promo_response_percentile,
            PERCENT_RANK() OVER (ORDER BY orders_per_op_area) AS op_area_efficiency_percentile
        FROM metrics
    ),
    scored AS (
        SELECT
            *,
            CASE WHEN demand_percentile >= 0.90 THEN 5 WHEN demand_percentile >= 0.75 THEN 4 WHEN demand_percentile >= 0.50 THEN 3 WHEN demand_percentile >= 0.25 THEN 2 ELSE 1 END AS demand_scale_score,
            CASE WHEN volatility_percentile >= 0.90 THEN 5 WHEN volatility_percentile >= 0.75 THEN 4 WHEN volatility_percentile >= 0.50 THEN 3 WHEN volatility_percentile >= 0.25 THEN 2 ELSE 1 END AS demand_volatility_score,
            CASE WHEN promo_response_percentile >= 0.90 THEN 5 WHEN promo_response_percentile >= 0.75 THEN 4 WHEN promo_response_percentile >= 0.50 THEN 3 WHEN promo_response_percentile >= 0.25 THEN 2 ELSE 1 END AS promotion_response_score,
            CASE WHEN op_area_efficiency_percentile >= 0.90 THEN 5 WHEN op_area_efficiency_percentile >= 0.75 THEN 4 WHEN op_area_efficiency_percentile >= 0.50 THEN 3 WHEN op_area_efficiency_percentile >= 0.25 THEN 2 ELSE 1 END AS orders_per_op_area_score
        FROM ranked
    )
    SELECT
        center_id,
        meal_id,
        category,
        cuisine,
        city_code,
        region_code,
        center_type,
        op_area,
        total_orders,
        ROUND(avg_weekly_orders, 2) AS avg_weekly_orders,
        ROUND(coefficient_of_variation, 4) AS coefficient_of_variation,
        ROUND(COALESCE(promo_lift_ratio, 0), 4) AS promo_lift_ratio,
        ROUND(orders_per_op_area, 2) AS orders_per_op_area,
        demand_scale_score,
        demand_volatility_score,
        promotion_response_score,
        orders_per_op_area_score,
        demand_scale_score + demand_volatility_score + promotion_response_score + orders_per_op_area_score AS replenishment_priority_score
    FROM scored
)
ORDER BY replenishment_priority_score DESC, total_orders DESC
LIMIT 30;

-- output: 15_high_demand_volatile_items.csv
SELECT *
FROM (
    WITH center_meal_week AS (
        SELECT
            center_id,
            meal_id,
            category,
            cuisine,
            city_code,
            region_code,
            center_type,
            op_area,
            week,
            SUM(num_orders) AS weekly_orders,
            MAX(promotion_flag) AS promoted_in_week
        FROM v_train_enriched
        GROUP BY center_id, meal_id, category, cuisine, city_code, region_code, center_type, op_area, week
    ),
    metrics AS (
        SELECT
            center_id,
            meal_id,
            category,
            cuisine,
            city_code,
            region_code,
            center_type,
            op_area,
            COUNT(*) AS observed_weeks,
            SUM(weekly_orders) AS total_orders,
            AVG(weekly_orders) AS avg_weekly_orders,
            sqrt(AVG(weekly_orders * weekly_orders) - AVG(weekly_orders) * AVG(weekly_orders)) AS stddev_weekly_orders,
            SUM(CASE WHEN promoted_in_week = 1 THEN weekly_orders ELSE 0 END) * 1.0 / NULLIF(SUM(weekly_orders), 0) AS promo_order_share,
            AVG(CASE WHEN promoted_in_week = 1 THEN weekly_orders END) AS avg_orders_promoted_weeks,
            AVG(CASE WHEN promoted_in_week = 0 THEN weekly_orders END) AS avg_orders_non_promoted_weeks
        FROM center_meal_week
        GROUP BY center_id, meal_id, category, cuisine, city_code, region_code, center_type, op_area
    ),
    scored AS (
        SELECT
            *,
            stddev_weekly_orders / NULLIF(avg_weekly_orders, 0) AS coefficient_of_variation,
            PERCENT_RANK() OVER (ORDER BY avg_weekly_orders) AS demand_percentile,
            PERCENT_RANK() OVER (ORDER BY stddev_weekly_orders / NULLIF(avg_weekly_orders, 0)) AS volatility_percentile
        FROM metrics
    )
    SELECT
        center_id,
        meal_id,
        category,
        cuisine,
        city_code,
        region_code,
        center_type,
        op_area,
        total_orders,
        ROUND(avg_weekly_orders, 2) AS avg_weekly_orders,
        ROUND(coefficient_of_variation, 4) AS coefficient_of_variation,
        ROUND(demand_percentile, 4) AS demand_percentile,
        ROUND(volatility_percentile, 4) AS volatility_percentile
    FROM scored
    WHERE demand_percentile >= 0.70
        AND volatility_percentile >= 0.65
)
ORDER BY total_orders DESC
LIMIT 50;

-- output: 16_center_flexible_replenishment_plan.csv
WITH center_meal_week AS (
    SELECT
        center_id,
        meal_id,
        category,
        cuisine,
        city_code,
        region_code,
        center_type,
        op_area,
        week,
        SUM(num_orders) AS weekly_orders,
        MAX(promotion_flag) AS promoted_in_week
    FROM v_train_enriched
    GROUP BY center_id, meal_id, category, cuisine, city_code, region_code, center_type, op_area, week
),
metrics AS (
    SELECT
        center_id,
        meal_id,
        city_code,
        region_code,
        center_type,
        op_area,
        SUM(weekly_orders) AS total_orders,
        AVG(weekly_orders) AS avg_weekly_orders,
        sqrt(AVG(weekly_orders * weekly_orders) - AVG(weekly_orders) * AVG(weekly_orders)) AS stddev_weekly_orders
    FROM center_meal_week
    GROUP BY center_id, meal_id, city_code, region_code, center_type, op_area
),
scored AS (
    SELECT
        *,
        stddev_weekly_orders / NULLIF(avg_weekly_orders, 0) AS coefficient_of_variation,
        PERCENT_RANK() OVER (ORDER BY avg_weekly_orders) AS demand_percentile,
        PERCENT_RANK() OVER (ORDER BY stddev_weekly_orders / NULLIF(avg_weekly_orders, 0)) AS volatility_percentile
    FROM metrics
),
classified AS (
    SELECT
        *,
        CASE
            WHEN demand_percentile >= 0.70 AND volatility_percentile >= 0.65 THEN 1
            ELSE 0
        END AS high_demand_volatile_flag
    FROM scored
)
SELECT
    center_id,
    city_code,
    region_code,
    center_type,
    op_area,
    COUNT(DISTINCT meal_id) AS meal_combinations,
    SUM(total_orders) AS total_orders,
    ROUND(AVG(avg_weekly_orders), 2) AS avg_pair_weekly_orders,
    ROUND(AVG(coefficient_of_variation), 4) AS avg_pair_coefficient_of_variation,
    SUM(high_demand_volatile_flag) AS high_demand_volatile_pairs,
    ROUND(SUM(high_demand_volatile_flag) * 100.0 / COUNT(DISTINCT meal_id), 2) AS volatile_pair_share_pct
FROM classified
GROUP BY center_id, city_code, region_code, center_type, op_area
ORDER BY high_demand_volatile_pairs DESC, avg_pair_coefficient_of_variation DESC;

-- output: 17_low_demand_low_priority_items.csv
SELECT *
FROM (
    WITH center_meal_week AS (
        SELECT
            center_id,
            meal_id,
            category,
            cuisine,
            city_code,
            region_code,
            center_type,
            op_area,
            week,
            SUM(num_orders) AS weekly_orders,
            MAX(promotion_flag) AS promoted_in_week
        FROM v_train_enriched
        GROUP BY center_id, meal_id, category, cuisine, city_code, region_code, center_type, op_area, week
    ),
    metrics AS (
        SELECT
            center_id,
            meal_id,
            category,
            cuisine,
            city_code,
            region_code,
            center_type,
            op_area,
            SUM(weekly_orders) AS total_orders,
            AVG(weekly_orders) AS avg_weekly_orders,
            sqrt(AVG(weekly_orders * weekly_orders) - AVG(weekly_orders) * AVG(weekly_orders)) AS stddev_weekly_orders,
            SUM(CASE WHEN promoted_in_week = 1 THEN weekly_orders ELSE 0 END) * 1.0 / NULLIF(SUM(weekly_orders), 0) AS promo_order_share,
            AVG(CASE WHEN promoted_in_week = 1 THEN weekly_orders END) AS avg_orders_promoted_weeks,
            AVG(CASE WHEN promoted_in_week = 0 THEN weekly_orders END) AS avg_orders_non_promoted_weeks
        FROM center_meal_week
        GROUP BY center_id, meal_id, category, cuisine, city_code, region_code, center_type, op_area
    ),
    scored AS (
        SELECT
            *,
            stddev_weekly_orders / NULLIF(avg_weekly_orders, 0) AS coefficient_of_variation,
            (avg_orders_promoted_weeks - avg_orders_non_promoted_weeks)
                / NULLIF(avg_orders_non_promoted_weeks, 0) AS promo_lift_ratio,
            PERCENT_RANK() OVER (ORDER BY avg_weekly_orders) AS demand_percentile,
            PERCENT_RANK() OVER (ORDER BY stddev_weekly_orders / NULLIF(avg_weekly_orders, 0)) AS volatility_percentile
        FROM metrics
    )
    SELECT
        center_id,
        meal_id,
        category,
        cuisine,
        city_code,
        region_code,
        center_type,
        op_area,
        total_orders,
        ROUND(avg_weekly_orders, 2) AS avg_weekly_orders,
        ROUND(coefficient_of_variation, 4) AS coefficient_of_variation,
        ROUND(COALESCE(promo_lift_ratio, 0), 4) AS promo_lift_ratio,
        ROUND(promo_order_share, 4) AS promo_order_share,
        ROUND(demand_percentile, 4) AS demand_percentile
    FROM scored
    WHERE demand_percentile < 0.25
        AND COALESCE(promo_lift_ratio, 0) < 0.75
        AND COALESCE(promo_order_share, 0) < 0.35
)
ORDER BY total_orders ASC
LIMIT 50;
