-- output: 00_final_combined_table.csv
SELECT
    id,
    week,
    center_id,
    city_code,
    region_code,
    center_type,
    op_area,
    meal_id,
    category,
    cuisine,
    checkout_price,
    base_price,
    discount_rate,
    discount_bucket,
    emailer_for_promotion,
    homepage_featured,
    promotion_flag,
    num_orders,
    gross_sales_proxy
FROM v_train_enriched;

-- output: 01_business_overview_summary.csv
SELECT
    COUNT(*) AS training_rows,
    COUNT(DISTINCT week) AS training_weeks,
    MIN(week) AS first_train_week,
    MAX(week) AS last_train_week,
    COUNT(DISTINCT center_id) AS fulfilment_centers,
    COUNT(DISTINCT meal_id) AS meals,
    COUNT(DISTINCT category) AS meal_categories,
    COUNT(DISTINCT cuisine) AS cuisines,
    SUM(num_orders) AS total_orders,
    ROUND(AVG(num_orders), 2) AS avg_orders_per_observation,
    ROUND(SUM(gross_sales_proxy), 2) AS gross_sales_proxy
FROM v_train_enriched;

-- output: 02_weekly_demand_trend.csv
SELECT
    week,
    SUM(num_orders) AS total_orders,
    ROUND(AVG(num_orders), 2) AS avg_orders_per_observation,
    COUNT(DISTINCT center_id) AS active_centers,
    COUNT(DISTINCT meal_id) AS active_meals
FROM v_train_enriched
GROUP BY week
ORDER BY week;

-- output: 03_region_center_overview.csv
SELECT
    region_code,
    center_type,
    COUNT(DISTINCT center_id) AS centers,
    SUM(num_orders) AS total_orders,
    ROUND(AVG(num_orders), 2) AS avg_orders,
    ROUND(SUM(num_orders) * 100.0 / SUM(SUM(num_orders)) OVER (), 2) AS order_share_pct
FROM v_train_enriched
GROUP BY region_code, center_type
ORDER BY total_orders DESC;
