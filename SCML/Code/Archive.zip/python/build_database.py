import csv
import sqlite3
from pathlib import Path


ROOT = Path(__file__).resolve().parents[2]
WORK = ROOT / "analysis"
DATA = ROOT / "Data"
DB_PATH = WORK / "database" / "food_demand.sqlite"
SCHEMA_PATH = WORK / "sql" / "00_schema.sql"


LOAD_ORDER = [
    ("meal_info", "meal_info.csv"),
    ("fulfilment_center_info", "fulfilment_center_info.csv"),
    ("train", "train.csv"),
    ("test", "test.csv"),
]


def load_csv(conn: sqlite3.Connection, table: str, csv_path: Path) -> None:
    with csv_path.open(newline="") as handle:
        reader = csv.reader(handle)
        headers = next(reader)
        columns = ", ".join(headers)
        placeholders = ", ".join(["?"] * len(headers))
        conn.executemany(
            f"INSERT INTO {table} ({columns}) VALUES ({placeholders})",
            reader,
        )


def main() -> None:
    DB_PATH.parent.mkdir(parents=True, exist_ok=True)
    if DB_PATH.exists():
        DB_PATH.unlink()

    conn = sqlite3.connect(DB_PATH)
    try:
        schema_sql = SCHEMA_PATH.read_text()
        table_sql, view_sql = schema_sql.split("CREATE VIEW v_train_enriched", 1)
        conn.executescript(table_sql)
        for table, filename in LOAD_ORDER:
            load_csv(conn, table, DATA / filename)
        conn.executescript("CREATE VIEW v_train_enriched" + view_sql)
        conn.commit()
    finally:
        conn.close()

    print(f"Built database: {DB_PATH}")


if __name__ == "__main__":
    main()
