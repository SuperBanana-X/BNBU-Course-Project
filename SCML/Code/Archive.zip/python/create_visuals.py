from pathlib import Path
import os
import textwrap


ROOT = Path(__file__).resolve().parents[2]
WORK = ROOT / "analysis"
OUTPUTS = WORK / "outputs"
VISUALS = WORK / "visuals"
MPLCONFIG = WORK / ".mplconfig"
CACHE = WORK / ".cache"

os.environ["MPLCONFIGDIR"] = str(MPLCONFIG)
os.environ["XDG_CACHE_HOME"] = str(CACHE)
MPLCONFIG.mkdir(parents=True, exist_ok=True)
CACHE.mkdir(parents=True, exist_ok=True)
VISUALS.mkdir(parents=True, exist_ok=True)

import matplotlib.pyplot as plt
from matplotlib.colors import LinearSegmentedColormap
from matplotlib.font_manager import FontProperties
from matplotlib.lines import Line2D
import numpy as np
import pandas as pd


COLORS = {
    "ink": "#101820",
    "charcoal": "#252A31",
    "blue": "#003A70",
    "steel": "#2B638F",
    "cyan": "#008CC8",
    "gold": "#8A7A35",
    "red": "#5F4B5B",
    "grey": "#3F4650",
    "rule": "#6D8193",
    "mid_grey": "#6F7A86",
    "light_grey": "#D8E0E8",
    "pale_grey": "#F5F7FA",
    "bg": "#FFFFFF",
}
ACCENT_GRADIENT = LinearSegmentedColormap.from_list(
    "mck_blue",
    [COLORS["pale_grey"], "#D9EAF4", "#83B4D1", COLORS["steel"]],
)
FONT_PATHS = [
    Path("/System/Library/Fonts/Hiragino Sans GB.ttc"),
    Path("/System/Library/Fonts/STHeiti Medium.ttc"),
    Path("/System/Library/Fonts/Supplemental/Arial Unicode.ttf"),
]
TABLE_FONT_PATH = next((path for path in FONT_PATHS if path.exists()), None)
TABLE_FONT = FontProperties(fname=str(TABLE_FONT_PATH)) if TABLE_FONT_PATH else None
TABLE_FONT_BOLD = FontProperties(fname=str(TABLE_FONT_PATH), weight="bold") if TABLE_FONT_PATH else None


def set_style():
    plt.rcParams.update(
        {
            "figure.facecolor": COLORS["bg"],
            "axes.facecolor": COLORS["bg"],
            "axes.edgecolor": COLORS["light_grey"],
            "axes.labelcolor": COLORS["ink"],
            "xtick.color": COLORS["charcoal"],
            "ytick.color": COLORS["charcoal"],
            "font.family": "DejaVu Sans",
            "font.sans-serif": [
                "DejaVu Sans",
                "Hiragino Sans GB",
                "STHeiti",
                "Arial Unicode MS",
            ],
            "font.size": 9.5,
            "axes.titleweight": "bold",
            "axes.titlesize": 15,
            "axes.titlecolor": COLORS["ink"],
            "axes.labelsize": 10.2,
            "legend.frameon": False,
            "savefig.dpi": 220,
            "savefig.bbox": "standard",
            "savefig.facecolor": COLORS["bg"],
        }
    )


def format_axis(ax, grid_axis=None):
    ax.spines["top"].set_visible(False)
    ax.spines["right"].set_visible(False)
    ax.spines["left"].set_visible(False)
    ax.spines["bottom"].set_color(COLORS["mid_grey"])
    ax.spines["bottom"].set_linewidth(0.8)
    ax.grid(False)
    ax.tick_params(axis="y", length=0)
    ax.tick_params(axis="x", length=3, colors=COLORS["charcoal"], labelsize=9.4)
    ax.tick_params(axis="y", colors=COLORS["charcoal"], labelsize=9.4)


def add_header(ax, eyebrow, title, subtitle):
    fig = ax.figure
    if ax.axison:
        fig.subplots_adjust(top=0.66)
    fig.add_artist(Line2D(
        [0.075, 0.175],
        [0.955, 0.955],
        transform=fig.transFigure,
        color=COLORS["rule"],
        linewidth=2.4,
        solid_capstyle="butt",
    ))
    fig.text(
        0.075,
        0.912,
        eyebrow.upper(),
        ha="left",
        va="bottom",
        fontsize=8.2,
        fontweight="bold",
        color=COLORS["blue"],
        linespacing=1.0,
    )
    fig.text(
        0.075,
        0.815,
        title,
        ha="left",
        va="bottom",
        fontsize=15.6,
        fontweight="bold",
        color=COLORS["ink"],
        linespacing=1.05,
    )
    fig.text(
        0.075,
        0.745,
        subtitle,
        ha="left",
        va="bottom",
        color=COLORS["grey"],
        fontsize=9.8,
    )


def add_source(ax):
    return None


def save(fig, filename):
    fig.savefig(VISUALS / filename, bbox_inches=None)
    plt.close(fig)


def wrap_text(value, width):
    return textwrap.fill(
        str(value),
        width=width,
        break_long_words=True,
        break_on_hyphens=False,
        replace_whitespace=False,
    )


def draw_table_exhibit(filename, eyebrow, title, subtitle, columns, rows, col_widths, wrap_widths):
    wrapped_rows = [[wrap_text(cell, wrap_widths[i]) for i, cell in enumerate(row)] for row in rows]
    line_counts = [max(cell.count("\n") + 1 for cell in row) for row in wrapped_rows]
    row_heights = [0.082 + 0.048 * (count - 1) for count in line_counts]
    table_height = 0.095 + sum(row_heights)
    fig_height = max(3.4, 2.0 + 0.34 * len(rows) + 0.08 * max(line_counts))
    fig, ax = plt.subplots(figsize=(12.4, fig_height))
    ax.axis("off")
    add_header(ax, eyebrow, title, subtitle)

    left = 0.0
    top = 0.68
    total_width = 1.0
    widths = np.array(col_widths, dtype=float)
    widths = widths / widths.sum() * total_width
    scale = min(1.24, max(1.0, (top - 0.12) / table_height))
    row_heights = [height * scale for height in row_heights]

    ax.plot(
        [left, left + total_width],
        [top, top],
        transform=ax.transAxes,
        color=COLORS["blue"],
        linewidth=3.1,
        solid_capstyle="butt",
        clip_on=False,
    )

    header_h = 0.095 * scale
    x = left
    for i, column in enumerate(columns):
        ax.add_patch(
            plt.Rectangle(
                (x, top - header_h),
                widths[i],
                header_h,
                transform=ax.transAxes,
                facecolor=COLORS["pale_grey"],
                edgecolor="none",
            )
        )
        ax.text(
            x + 0.012,
            top - header_h / 2,
            column.upper(),
            transform=ax.transAxes,
            ha="left",
            va="center",
            fontsize=8.2,
            fontweight="bold",
            color=COLORS["ink"],
            fontproperties=TABLE_FONT_BOLD,
        )
        x += widths[i]

    ax.plot(
        [left, left + total_width],
        [top - header_h, top - header_h],
        transform=ax.transAxes,
        color=COLORS["charcoal"],
        linewidth=1.2,
        clip_on=False,
    )

    y = top - header_h
    for r, row in enumerate(wrapped_rows):
        h = row_heights[r]
        fill = COLORS["bg"] if r % 2 == 0 else "#FBFCFD"
        ax.add_patch(
            plt.Rectangle(
                (left, y - h),
                total_width,
                h,
                transform=ax.transAxes,
                facecolor=fill,
                edgecolor="none",
            )
        )
        x = left
        for i, cell in enumerate(row):
            compact = cell.replace("\n", "")
            is_numeric = i > 0 and all(ch in "0123456789.,%- " for ch in compact)
            ax.text(
                x + widths[i] - 0.012 if is_numeric else x + 0.012,
                y - 0.026,
                cell,
                transform=ax.transAxes,
                ha="right" if is_numeric else "left",
                va="top",
                fontsize=8.5,
                color=COLORS["charcoal"],
                linespacing=1.25,
                fontproperties=TABLE_FONT,
            )
            x += widths[i]
        ax.plot(
            [left, left + total_width],
            [y - h, y - h],
            transform=ax.transAxes,
            color=COLORS["light_grey"],
            linewidth=0.8,
            clip_on=False,
        )
        y -= h

    save(fig, filename)


def plot_weekly_demand():
    df = pd.read_csv(OUTPUTS / "02_weekly_demand_trend.csv")
    fig, ax = plt.subplots(figsize=(11, 5.5))
    ax.plot(df["week"], df["total_orders"] / 1_000_000, color=COLORS["blue"], linewidth=2.4)
    add_header(
        ax,
        "Business overview",
        "Weekly order demand shows material planning volatility",
        "Total weekly orders across all fulfilment centers and meals",
    )
    fig.subplots_adjust(left=0.12, right=0.95, bottom=0.12, top=0.66)
    ax.set_xlabel("Week")
    ax.set_ylabel("Orders, million")
    format_axis(ax, grid_axis="y")
    add_source(ax)
    save(fig, "01_weekly_demand_trend.png")


def plot_meal_category_demand():
    df = pd.read_csv(OUTPUTS / "04_meal_category_demand_diagnosis.csv").head(10)
    df = df.sort_values("total_orders")
    labels = df["category"] + " | " + df["cuisine"]
    fig, ax = plt.subplots(figsize=(10.5, 6.2))
    colors = [COLORS["blue"] if i >= len(df) - 3 else COLORS["light_grey"] for i in range(len(df))]
    bars = ax.barh(labels, df["total_orders"] / 1_000_000, color=colors)
    add_header(
        ax,
        "Meal demand",
        "Three category-cuisine groups account for 47% of demand",
        "Top category-cuisine groups by historical order share",
    )
    fig.subplots_adjust(left=0.25, right=0.92, bottom=0.12, top=0.66)
    ax.set_xlabel("Orders, million")
    ax.set_ylabel("")
    format_axis(ax, grid_axis="x")
    for bar, share in zip(bars, df["order_share_pct"]):
        ax.text(
            bar.get_width() + 0.15,
            bar.get_y() + bar.get_height() / 2,
            f"{share:.1f}%",
            va="center",
            fontsize=9,
            color=COLORS["charcoal"],
        )
    add_source(ax)
    save(fig, "02_meal_category_demand.png")


def plot_center_volatility():
    df = pd.read_csv(OUTPUTS / "07_top_volatile_centers.csv").head(15)
    df = df.sort_values("coefficient_of_variation")
    labels = "Center " + df["center_id"].astype(str) + " | Region " + df["region_code"].astype(str)
    fig, ax = plt.subplots(figsize=(10.5, 6.2))
    colors = [COLORS["blue"] if i >= len(df) - 5 else COLORS["light_grey"] for i in range(len(df))]
    bars = ax.barh(labels, df["coefficient_of_variation"], color=colors)
    add_header(
        ax,
        "Center volatility",
        "Demand volatility is concentrated in a small set of centers",
        "Coefficient of variation by fulfilment center",
    )
    fig.subplots_adjust(left=0.25, right=0.92, bottom=0.12, top=0.66)
    ax.set_xlabel("Coefficient of variation")
    ax.set_ylabel("")
    format_axis(ax, grid_axis="x")
    for bar, avg_orders in zip(bars, df["avg_weekly_orders"]):
        ax.text(
            bar.get_width() + 0.006,
            bar.get_y() + bar.get_height() / 2,
            f"{avg_orders:,.0f}/wk",
            va="center",
            fontsize=8.5,
            color=COLORS["charcoal"],
        )
    add_source(ax)
    save(fig, "03_center_demand_volatility.png")


def plot_promotion_effect():
    df = pd.read_csv(OUTPUTS / "08_promotion_effect_diagnosis.csv")
    order = ["No Promotion", "Homepage Only", "Email Only", "Email + Homepage"]
    df["promotion_group"] = pd.Categorical(df["promotion_group"], categories=order, ordered=True)
    df = df.sort_values("promotion_group")
    fig, ax = plt.subplots(figsize=(9.5, 5.6))
    colors = [COLORS["light_grey"], COLORS["mid_grey"], COLORS["steel"], COLORS["blue"]]
    bars = ax.bar(df["promotion_group"].astype(str), df["avg_orders"], color=colors)
    add_header(
        ax,
        "Promotion",
        "Combined promotion exposure is associated with the highest order volume",
        "Average orders by promotion exposure group",
    )
    fig.subplots_adjust(left=0.14, right=0.95, bottom=0.16, top=0.66)
    ax.set_xlabel("")
    ax.set_ylabel("Average orders per observation")
    format_axis(ax, grid_axis="y")
    ax.tick_params(axis="x", rotation=0)
    for bar in bars:
        ax.text(
            bar.get_x() + bar.get_width() / 2,
            bar.get_height() + 18,
            f"{bar.get_height():,.0f}",
            ha="center",
            fontsize=9,
            color=COLORS["charcoal"],
        )
    add_source(ax)
    save(fig, "04_promotion_effect.png")


def plot_demand_risk_summary():
    df = pd.read_csv(OUTPUTS / "12_demand_risk_class_summary.csv")
    order = [
        "High Demand Stable",
        "High Demand Volatile",
        "Low Demand Promotion Dependent",
        "Low Demand Low Priority",
    ]
    color_map = {
        "High Demand Stable": COLORS["blue"],
        "High Demand Volatile": COLORS["steel"],
        "Low Demand Promotion Dependent": COLORS["mid_grey"],
        "Low Demand Low Priority": COLORS["light_grey"],
    }
    df["demand_risk_class"] = pd.Categorical(df["demand_risk_class"], categories=order, ordered=True)
    df = df.sort_values("demand_risk_class")
    fig, ax = plt.subplots(figsize=(10.5, 5.8))
    bars = ax.bar(
        df["demand_risk_class"].astype(str),
        df["center_meal_combinations"],
        color=[color_map[x] for x in df["demand_risk_class"].astype(str)],
    )
    add_header(
        ax,
        "Demand risk",
        "Risk segments translate demand signals into supply-chain actions",
        "Classification based on demand scale, volatility and promotion dependency",
    )
    fig.subplots_adjust(left=0.14, right=0.95, bottom=0.20, top=0.66)
    ax.set_xlabel("")
    ax.set_ylabel("Center-meal combinations")
    format_axis(ax, grid_axis="y")
    ax.tick_params(axis="x", rotation=18)
    for bar, orders in zip(bars, df["total_orders"]):
        ax.text(
            bar.get_x() + bar.get_width() / 2,
            bar.get_height() + 35,
            f"{orders / 1_000_000:.1f}M orders",
            ha="center",
            fontsize=8.5,
            color=COLORS["charcoal"],
        )
    add_source(ax)
    save(fig, "05_demand_risk_classification.png")


def plot_priority_score():
    df = pd.read_csv(OUTPUTS / "14_top_replenishment_priority.csv").head(15)
    df = df.sort_values("total_orders")
    labels = "C" + df["center_id"].astype(str) + " - M" + df["meal_id"].astype(str)
    fig, ax = plt.subplots(figsize=(10.5, 6.2))
    colors = [COLORS["blue"] if i >= len(df) - 4 else COLORS["light_grey"] for i in range(len(df))]
    bars = ax.barh(labels, df["total_orders"] / 1000, color=colors)
    add_header(
        ax,
        "Replenishment priority",
        "Maximum-priority combinations differ materially by order scale",
        "All combinations shown have maximum priority score of 20",
    )
    fig.subplots_adjust(left=0.16, right=0.90, bottom=0.12, top=0.66)
    ax.set_xlabel("Total orders, thousand")
    ax.set_ylabel("")
    format_axis(ax, grid_axis="x")
    ax.set_xlim(0, (df["total_orders"].max() / 1000) * 1.35)
    for bar, category, cv, score in zip(
        bars,
        df["category"],
        df["coefficient_of_variation"],
        df["replenishment_priority_score"],
    ):
        ax.text(
            bar.get_width() + 3,
            bar.get_y() + bar.get_height() / 2,
            f"{category}, score {score:.0f}, CV {cv:.2f}",
            va="center",
            fontsize=8.5,
            color=COLORS["charcoal"],
        )
    add_source(ax)
    save(fig, "06_replenishment_priority_score.png")


def plot_discount_effect():
    df = pd.read_csv(OUTPUTS / "09_discount_effect_diagnosis.csv")
    order = ["price_above_base", "no_discount", "0-5%", "5-10%", "10-20%", ">20%"]
    df["discount_bucket"] = pd.Categorical(df["discount_bucket"], categories=order, ordered=True)
    df = df.sort_values("discount_bucket")
    fig, ax = plt.subplots(figsize=(9.8, 5.6))
    colors = [COLORS["light_grey"], COLORS["light_grey"], COLORS["mid_grey"], COLORS["steel"], COLORS["blue"], COLORS["blue"]]
    bars = ax.bar(df["discount_bucket"].astype(str), df["avg_orders"], color=colors)
    add_header(
        ax,
        "Discount",
        "Discount depth is not a sufficient demand signal on its own",
        "Average orders by checkout-price discount bucket",
    )
    fig.subplots_adjust(left=0.14, right=0.95, bottom=0.16, top=0.66)
    ax.set_xlabel("Discount bucket")
    ax.set_ylabel("Average orders per observation")
    format_axis(ax, grid_axis="y")
    for bar in bars:
        ax.text(
            bar.get_x() + bar.get_width() / 2,
            bar.get_height() + 12,
            f"{bar.get_height():,.0f}",
            ha="center",
            fontsize=8.5,
            color=COLORS["charcoal"],
        )
    add_source(ax)
    save(fig, "08_discount_effect.png")


def plot_promotion_discount_heatmap():
    df = pd.read_csv(OUTPUTS / "10_promotion_discount_interaction.csv")
    discount_order = ["price_above_base", "no_discount", "0-5%", "5-10%", "10-20%", ">20%"]
    discount_labels = ["Above base", "No discount", "0-5%", "5-10%", "10-20%", ">20%"]
    promo_order = ["Not Promoted", "Promoted"]
    pivot = (
        df.pivot(index="promotion_status", columns="discount_bucket", values="avg_orders")
        .reindex(index=promo_order, columns=discount_order)
    )
    values = pivot.to_numpy(dtype=float)
    fig, ax = plt.subplots(figsize=(10.5, 4.8))
    im = ax.imshow(values, cmap=ACCENT_GRADIENT, aspect="auto", vmin=160, vmax=700)
    add_header(
        ax,
        "Promotion x discount",
        "Promotion exposure dominates the discount response pattern",
        "Average orders by promotion status and checkout-price discount bucket",
    )
    fig.subplots_adjust(left=0.15, right=0.88, bottom=0.16, top=0.66)
    ax.set_xticks(range(len(discount_order)))
    ax.set_xticklabels(discount_labels)
    ax.set_yticks(range(len(promo_order)))
    ax.set_yticklabels(promo_order)
    for i in range(values.shape[0]):
        for j in range(values.shape[1]):
            if np.isfinite(values[i, j]):
                ax.text(j, i, f"{values[i, j]:.0f}", ha="center", va="center", color=COLORS["ink"], fontsize=9)
    ax.spines[:].set_visible(False)
    cbar = fig.colorbar(im, ax=ax, fraction=0.035, pad=0.02)
    cbar.ax.tick_params(labelsize=8, colors=COLORS["grey"])
    add_source(ax)
    save(fig, "09_promotion_discount_heatmap.png")


def plot_center_flexible_replenishment():
    df = pd.read_csv(OUTPUTS / "16_center_flexible_replenishment_plan.csv")
    fig, ax = plt.subplots(figsize=(9.8, 6.4))
    type_colors = {"TYPE_A": COLORS["blue"], "TYPE_B": COLORS["steel"], "TYPE_C": COLORS["mid_grey"]}
    for center_type, group in df.groupby("center_type"):
        ax.scatter(
            group["total_orders"] / 1_000_000,
            group["avg_pair_coefficient_of_variation"],
            s=np.clip(group["high_demand_volatile_pairs"] * 28, 35, 520),
            color=type_colors.get(center_type, COLORS["grey"]),
            alpha=0.68,
            label=center_type,
            edgecolors="white",
            linewidth=0.8,
        )
    top = df.sort_values("high_demand_volatile_pairs", ascending=False).head(5)
    label_offsets = {
        101: (0.075, -0.018),
        110: (-0.155, 0.020),
    }
    for _, row in top.iterrows():
        center_id = int(row["center_id"])
        dx, dy = label_offsets.get(center_id, (0.025, 0.006))
        ax.text(
            row["total_orders"] / 1_000_000 + dx,
            row["avg_pair_coefficient_of_variation"] + dy,
            f"C{center_id}",
            fontsize=8.7,
            fontweight="bold",
            color=COLORS["charcoal"],
            bbox={"facecolor": COLORS["bg"], "edgecolor": "none", "pad": 1.2, "alpha": 0.88},
        )
    add_header(
        ax,
        "Flexible replenishment",
        "Centers with volatile high-demand pairs require agile replenishment",
        "Bubble size shows high-demand volatile meal pairs",
    )
    fig.subplots_adjust(left=0.14, right=0.88, bottom=0.12, top=0.66)
    ax.set_xlabel("Total orders, million")
    ax.set_ylabel("Average pair-level coefficient of variation")
    format_axis(ax, grid_axis="y")
    ax.legend(title="Center type", loc="upper right", fontsize=8.5, title_fontsize=9)
    add_source(ax)
    save(fig, "10_center_flexible_replenishment.png")


def plot_priority_score_distribution():
    df = pd.read_csv(OUTPUTS / "13_replenishment_priority_score.csv")
    counts = df["replenishment_priority_score"].value_counts().sort_index()
    fig, ax = plt.subplots(figsize=(9.8, 5.4))
    bar_colors = [COLORS["light_grey"] if score < 15 else COLORS["blue"] for score in counts.index]
    bars = ax.bar(counts.index.astype(str), counts.values, color=bar_colors)
    add_header(
        ax,
        "Priority score",
        "Priority scores create actionable management tiers",
        "Distribution across center-meal combinations",
    )
    fig.subplots_adjust(left=0.14, right=0.95, bottom=0.14, top=0.66)
    ax.set_xlabel("Priority score")
    ax.set_ylabel("Center-meal combinations")
    format_axis(ax, grid_axis="y")
    for bar in bars:
        if bar.get_height() > 0:
            ax.text(
                bar.get_x() + bar.get_width() / 2,
                bar.get_height() + 8,
                f"{bar.get_height():,.0f}",
                ha="center",
                fontsize=8,
                color=COLORS["charcoal"],
            )
    add_source(ax)
    save(fig, "11_priority_score_distribution.png")


def plot_demand_volatility_matrix():
    df = pd.read_csv(OUTPUTS / "11_demand_risk_classification.csv")
    sample = df.copy()
    color_map = {
        "High Demand Stable": COLORS["blue"],
        "High Demand Volatile": COLORS["cyan"],
        "Low Demand Promotion Dependent": COLORS["gold"],
        "Low Demand Low Priority": COLORS["light_grey"],
    }
    fig, ax = plt.subplots(figsize=(9.5, 6.5))
    for cls, group in sample.groupby("demand_risk_class"):
        ax.scatter(
            group["avg_weekly_orders"],
            group["coefficient_of_variation"],
            s=np.clip(group["total_orders"] / 5000, 8, 90),
            alpha=0.66,
            color=color_map.get(cls, COLORS["grey"]),
            label=cls,
            edgecolors="none",
        )
    add_header(
        ax,
        "Demand-volatility matrix",
        "High-demand volatile pairs define the primary planning-risk zone",
        "Each bubble is one center-meal pair; size represents total orders",
    )
    fig.subplots_adjust(left=0.14, right=0.95, bottom=0.13, top=0.66)
    ax.set_xlabel("Average weekly orders")
    ax.set_ylabel("Coefficient of variation")
    ax.set_ylim(bottom=0)
    format_axis(ax, grid_axis="y")
    ax.legend(loc="upper right", fontsize=8.5)
    add_source(ax)
    save(fig, "07_demand_volatility_matrix.png")


def plot_table_demand_risk_logic():
    columns = ["Segment", "SQL rule", "Business meaning"]
    rows = [
        [
            "High Demand Stable",
            "demand_percentile >= 0.70 and volatility_percentile < 0.65",
            "High average weekly demand with manageable volatility; suitable for stable supply coverage",
        ],
        [
            "High Demand Volatile",
            "demand_percentile >= 0.70 and volatility_percentile >= 0.65",
            "High demand with elevated volatility; requires flexible replenishment",
        ],
        [
            "Low Demand Promotion Dependent",
            "demand_percentile < 0.70 and promo_lift_ratio >= 0.75 or promo_order_share >= 0.35",
            "Lower base demand, but promotion materially lifts orders or contributes a high share",
        ],
        [
            "Low Demand Low Priority",
            "All other combinations",
            "Low demand scale without strong promotion-dependency signal",
        ],
    ]
    draw_table_exhibit(
        "12_table_demand_risk_logic.png",
        "Exhibit 1",
        "Demand risk logic",
        "Center-meal pairs segmented by demand, volatility and promotion dependency",
        columns,
        rows,
        [1.35, 2.45, 2.55],
        [22, 41, 45],
    )


def plot_table_inventory_playbook():
    columns = ["Segment", "Management implication", "Recommended action"]
    rows = [
        ["High Demand Stable", "Large and relatively stable demand base", "Maintain stable replenishment; protect input supply and capacity"],
        ["High Demand Volatile", "Large demand with higher operating risk", "Use rolling forecasts, higher review frequency and pre-promotion checks"],
        ["Low Demand Promotion Dependent", "Low baseline demand that may spike during promotion", "Keep lean baseline inventory; replenish temporarily before promotions"],
        ["Low Demand Low Priority", "Weak demand with limited promotion signal", "Control stock levels and avoid capacity lock-up"],
    ]
    draw_table_exhibit(
        "13_table_inventory_playbook.png",
        "Exhibit 2",
        "Inventory playbook",
        "Each risk segment maps to a different replenishment action",
        columns,
        rows,
        [1.45, 2.35, 2.35],
        [24, 35, 42],
    )


def plot_table_percentile_score():
    columns = ["Percentile band", "Sub-score"]
    rows = [
        [">= 0.90", "5"],
        [">= 0.75 and < 0.90", "4"],
        [">= 0.50 and < 0.75", "3"],
        [">= 0.25 and < 0.50", "2"],
        ["< 0.25", "1"],
    ]
    draw_table_exhibit(
        "14_table_percentile_score.png",
        "Exhibit 3",
        "Priority score bands",
        "Same 1-5 scoring rule for demand, volatility, promotion response and op-area efficiency",
        columns,
        rows,
        [2.2, 1.0],
        [30, 8],
    )


def plot_table_low_priority_sample():
    df = pd.read_csv(OUTPUTS / "17_low_demand_low_priority_items.csv").head(5)
    columns = [
        "Center",
        "Meal",
        "Category",
        "Cuisine",
        "Total orders",
        "Avg weekly",
        "CV",
        "Promo lift",
        "Promo share",
        "Demand pct",
    ]
    rows = []
    for _, row in df.iterrows():
        rows.append(
            [
                f"{int(row['center_id'])}",
                f"{int(row['meal_id'])}",
                row["category"],
                row["cuisine"],
                f"{int(row['total_orders']):,}",
                f"{row['avg_weekly_orders']:.2f}",
                f"{row['coefficient_of_variation']:.4f}",
                f"{row['promo_lift_ratio']:.4f}",
                f"{row['promo_order_share']:.4f}",
                f"{row['demand_percentile']:.4f}",
            ]
        )
    draw_table_exhibit(
        "15_table_low_priority_sample.png",
        "Exhibit 4",
        "Low-priority sample",
        "Lowest-order center-meal pairs show weak demand and limited promotion response",
        columns,
        rows,
        [0.75, 0.75, 1.0, 1.15, 1.12, 1.12, 0.8, 1.12, 1.18, 1.1],
        [8, 8, 11, 12, 12, 11, 8, 11, 11, 11],
    )


def main():
    set_style()
    plot_weekly_demand()
    plot_meal_category_demand()
    plot_center_volatility()
    plot_promotion_effect()
    plot_demand_risk_summary()
    plot_priority_score()
    plot_demand_volatility_matrix()
    plot_discount_effect()
    plot_promotion_discount_heatmap()
    plot_center_flexible_replenishment()
    plot_priority_score_distribution()
    plot_table_demand_risk_logic()
    plot_table_inventory_playbook()
    plot_table_percentile_score()
    plot_table_low_priority_sample()
    print(f"Wrote visuals to {VISUALS}")


if __name__ == "__main__":
    main()
