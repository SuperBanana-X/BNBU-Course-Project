import re
import sqlite3
from pathlib import Path

import pandas as pd


ROOT = Path(__file__).resolve().parents[2]
WORK = ROOT / "analysis"
DB_PATH = WORK / "database" / "food_demand.sqlite"
SQL_DIR = WORK / "sql"
OUTPUT_DIR = WORK / "outputs"


OUTPUT_RE = re.compile(r"^--\s*output:\s*(?P<name>[A-Za-z0-9_.-]+)\s*$", re.MULTILINE)


def iter_queries(sql_text: str):
    matches = list(OUTPUT_RE.finditer(sql_text))
    for idx, match in enumerate(matches):
        start = match.end()
        end = matches[idx + 1].start() if idx + 1 < len(matches) else len(sql_text)
        output_name = match.group("name")
        query = sql_text[start:end].strip().rstrip(";")
        if query:
            yield output_name, query


def main() -> None:
    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
    conn = sqlite3.connect(DB_PATH)
    try:
        for sql_file in sorted(SQL_DIR.glob("[0-9][0-9]_*.sql")):
            if sql_file.name == "00_schema.sql":
                continue
            sql_text = sql_file.read_text()
            for output_name, query in iter_queries(sql_text):
                df = pd.read_sql_query(query, conn)
                out_path = OUTPUT_DIR / output_name
                df.to_csv(out_path, index=False)
                print(f"Wrote {out_path.relative_to(ROOT)} ({len(df):,} rows)")
    finally:
        conn.close()


if __name__ == "__main__":
    main()
